# WordPress MySQL database migration
#
# Generated: Friday 25. May 2018 03:02 UTC
# Hostname: localhost
# Database: `catalina`
# URL: //catalina.test
# Path: /srv/www/catalina/public_html
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, customize_changeset, issue, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#
INSERT INTO `wp_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_wp_trash_meta_status', '1'),
(2, 1, '_wp_trash_meta_time', '1527156471') ;

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-05-17 18:36:18', '2018-05-17 18:36:18', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'trash', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://catalina.test', 'yes'),
(2, 'home', 'http://catalina.test', 'yes'),
(3, 'blogname', 'Catalina', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@local.test', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:116:{s:8:"issue/?$";s:25:"index.php?post_type=issue";s:38:"issue/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=issue&feed=$matches[1]";s:33:"issue/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=issue&feed=$matches[1]";s:25:"issue/page/([0-9]{1,})/?$";s:43:"index.php?post_type=issue&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"issue/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"issue/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"issue/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"issue/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"issue/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"issue/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"issue/([^/]+)/embed/?$";s:38:"index.php?issue=$matches[1]&embed=true";s:26:"issue/([^/]+)/trackback/?$";s:32:"index.php?issue=$matches[1]&tb=1";s:46:"issue/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?issue=$matches[1]&feed=$matches[2]";s:41:"issue/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?issue=$matches[1]&feed=$matches[2]";s:34:"issue/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?issue=$matches[1]&paged=$matches[2]";s:41:"issue/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?issue=$matches[1]&cpage=$matches[2]";s:30:"issue/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?issue=$matches[1]&page=$matches[2]";s:22:"issue/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"issue/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"issue/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"issue/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"issue/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"issue/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"tpe/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?type=$matches[1]&feed=$matches[2]";s:39:"tpe/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?type=$matches[1]&feed=$matches[2]";s:20:"tpe/([^/]+)/embed/?$";s:37:"index.php?type=$matches[1]&embed=true";s:32:"tpe/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?type=$matches[1]&paged=$matches[2]";s:14:"tpe/([^/]+)/?$";s:26:"index.php?type=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:63:"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php";i:2;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:68:"/srv/www/catalina/public_html/wp-content/plugins/akismet/akismet.php";i:1;s:0:"";}', 'no'),
(40, 'template', 'catalina/resources', 'yes'),
(41, 'stylesheet', 'catalina/resources', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '8', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:5:{i:1527220364;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1527230193;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1527273437;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1527277950;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(113, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1526582251;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(124, 'can_compress_scripts', '1', 'no'),
(135, 'current_theme', 'Sage Starter Theme', 'yes'),
(136, 'theme_mods_catalina/resources', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(169, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(215, 'recently_activated', 'a:3:{s:47:"wp-migrate-db-pro-cli/wp-migrate-db-pro-cli.php";i:1526864191;s:19:"akismet/akismet.php";i:1526863424;s:25:"duplicator/duplicator.php";i:1526863419;}', 'yes'),
(216, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(236, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1527217321;}', 'no'),
(239, 'acf_version', '5.6.10', 'yes'),
(242, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRNeE5qQTNmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE9DMHdOUzB5TVNBd01Ub3lOVG8xTUE9PSI7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly9jYXRhbGluYS50ZXN0Ijt9', 'yes'),
(336, 'category_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 1, '_edit_lock', '1527164745:1'),
(3, 6, '_wp_trash_meta_status', 'publish'),
(4, 6, '_wp_trash_meta_time', '1526594409'),
(5, 7, '_wp_trash_meta_status', 'publish'),
(6, 7, '_wp_trash_meta_time', '1526594441'),
(8, 8, '_customize_changeset_uuid', 'a4d99e2a-3b3f-4667-a321-af3cf72ce653'),
(9, 9, '_edit_lock', '1526594724:1'),
(10, 9, '_wp_trash_meta_status', 'publish'),
(11, 9, '_wp_trash_meta_time', '1526594772'),
(12, 11, '_edit_last', '1'),
(13, 11, '_wp_page_template', 'views/template-issues.blade.php'),
(14, 11, '_edit_lock', '1527196547:1'),
(15, 13, '_edit_last', '1'),
(16, 13, '_wp_page_template', 'views/template-meet.blade.php'),
(17, 13, '_edit_lock', '1527022609:1'),
(18, 15, '_edit_last', '1'),
(19, 15, '_wp_page_template', 'views/template-news.blade.php'),
(20, 15, '_edit_lock', '1527197777:1'),
(24, 8, '_edit_lock', '1526765571:1'),
(25, 8, '_edit_last', '1'),
(26, 8, '_wp_page_template', 'views/template-home.blade.php'),
(27, 18, '_menu_item_type', 'post_type'),
(28, 18, '_menu_item_menu_item_parent', '0'),
(29, 18, '_menu_item_object_id', '8'),
(30, 18, '_menu_item_object', 'page'),
(31, 18, '_menu_item_target', ''),
(32, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(33, 18, '_menu_item_xfn', ''),
(34, 18, '_menu_item_url', ''),
(35, 18, '_menu_item_orphaned', '1526765717'),
(45, 20, '_menu_item_type', 'post_type'),
(46, 20, '_menu_item_menu_item_parent', '0'),
(47, 20, '_menu_item_object_id', '11'),
(48, 20, '_menu_item_object', 'page'),
(49, 20, '_menu_item_target', ''),
(50, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(51, 20, '_menu_item_xfn', ''),
(52, 20, '_menu_item_url', ''),
(54, 21, '_menu_item_type', 'post_type'),
(55, 21, '_menu_item_menu_item_parent', '0'),
(56, 21, '_menu_item_object_id', '13'),
(57, 21, '_menu_item_object', 'page'),
(58, 21, '_menu_item_target', ''),
(59, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(60, 21, '_menu_item_xfn', ''),
(61, 21, '_menu_item_url', ''),
(63, 22, '_menu_item_type', 'post_type'),
(64, 22, '_menu_item_menu_item_parent', '0'),
(65, 22, '_menu_item_object_id', '15'),
(66, 22, '_menu_item_object', 'page'),
(67, 22, '_menu_item_target', ''),
(68, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(69, 22, '_menu_item_xfn', ''),
(70, 22, '_menu_item_url', ''),
(72, 23, '_menu_item_type', 'custom'),
(73, 23, '_menu_item_menu_item_parent', '0'),
(74, 23, '_menu_item_object_id', '23'),
(75, 23, '_menu_item_object', 'custom'),
(76, 23, '_menu_item_target', ''),
(77, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(78, 23, '_menu_item_xfn', ''),
(79, 23, '_menu_item_url', 'http://soon'),
(81, 24, '_menu_item_type', 'custom'),
(82, 24, '_menu_item_menu_item_parent', '0'),
(83, 24, '_menu_item_object_id', '24'),
(84, 24, '_menu_item_object', 'custom'),
(85, 24, '_menu_item_target', ''),
(86, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(87, 24, '_menu_item_xfn', ''),
(88, 24, '_menu_item_url', 'http://soon'),
(89, 34, '_edit_last', '1'),
(90, 34, '_edit_lock', '1527197779:1'),
(94, 35, '_edit_last', '1'),
(95, 35, '_edit_lock', '1527194033:1'),
(96, 34, 'issue_subtitle', 'Subways and Buses are failing our community. Catalina has a plan.'),
(97, 34, '_issue_subtitle', 'field_5b0492dc64d8c'),
(98, 40, 'issue_subtitle', ''),
(99, 40, '_issue_subtitle', 'field_5b0492dc64d8c'),
(100, 41, 'issue_subtitle', 'Subways and Buses are failing our community. Catalina has a plan.'),
(101, 41, '_issue_subtitle', 'field_5b0492dc64d8c'),
(102, 42, '_wp_attached_file', '2018/05/CC_-027-0.jpg'),
(103, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2125;s:6:"height";i:2313;s:4:"file";s:21:"2018/05/CC_-027-0.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"CC_-027-0-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"CC_-027-0-276x300.jpg";s:5:"width";i:276;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"CC_-027-0-768x836.jpg";s:5:"width";i:768;s:6:"height";i:836;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"CC_-027-0-941x1024.jpg";s:5:"width";i:941;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1520538043";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(104, 34, '_thumbnail_id', '42'),
(105, 43, '_edit_last', '1'),
(106, 43, '_edit_lock', '1527042124:1'),
(107, 44, '_wp_attached_file', '2018/05/CC_-060.jpg'),
(108, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2139;s:6:"height";i:2336;s:4:"file";s:19:"2018/05/CC_-060.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"CC_-060-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"CC_-060-275x300.jpg";s:5:"width";i:275;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"CC_-060-768x839.jpg";s:5:"width";i:768;s:6:"height";i:839;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"CC_-060-938x1024.jpg";s:5:"width";i:938;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(109, 43, '_thumbnail_id', '44'),
(110, 43, 'issue_subtitle', 'The product of public schools, Catalina has a vision for improving education. '),
(111, 43, '_issue_subtitle', 'field_5b0492dc64d8c'),
(112, 45, 'issue_subtitle', 'The product of public schools, Catalina has a vision for improving education. '),
(113, 45, '_issue_subtitle', 'field_5b0492dc64d8c'),
(114, 46, '_edit_last', '1'),
(115, 46, '_edit_lock', '1527044888:1'),
(116, 47, '_wp_attached_file', '2018/05/CC_-072.jpg'),
(117, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1907;s:6:"height";i:2126;s:4:"file";s:19:"2018/05/CC_-072.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"CC_-072-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"CC_-072-269x300.jpg";s:5:"width";i:269;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"CC_-072-768x856.jpg";s:5:"width";i:768;s:6:"height";i:856;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"CC_-072-919x1024.jpg";s:5:"width";i:919;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(118, 46, '_thumbnail_id', '47'),
(119, 46, 'issue_subtitle', 'New York City has an affordability crisis. Catalina understands how to fix it.'),
(120, 46, '_issue_subtitle', 'field_5b0492dc64d8c'),
(121, 48, 'issue_subtitle', 'New York City has an affordability crisis. Catalina understands how to fix it.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(122, 48, '_issue_subtitle', 'field_5b0492dc64d8c'),
(123, 49, '_edit_last', '1'),
(124, 49, '_edit_lock', '1527046721:1'),
(125, 50, '_wp_attached_file', '2018/05/CC_-026-0.jpg'),
(126, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2016;s:6:"height";i:2187;s:4:"file";s:21:"2018/05/CC_-026-0.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"CC_-026-0-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"CC_-026-0-277x300.jpg";s:5:"width";i:277;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"CC_-026-0-768x833.jpg";s:5:"width";i:768;s:6:"height";i:833;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"CC_-026-0-944x1024.jpg";s:5:"width";i:944;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1520537816";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(127, 49, '_thumbnail_id', '50'),
(128, 49, 'issue_subtitle', 'New York State must provide protections for our community from Trump’s policies.'),
(129, 49, '_issue_subtitle', 'field_5b0492dc64d8c'),
(130, 51, 'issue_subtitle', 'New York State must provide protections for our community from Trump’s policies.'),
(131, 51, '_issue_subtitle', 'field_5b0492dc64d8c'),
(132, 52, '_edit_last', '1'),
(133, 52, '_edit_lock', '1527047670:1'),
(134, 53, '_wp_attached_file', '2018/05/CC_-044.jpg'),
(135, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1809;s:6:"height";i:1962;s:4:"file";s:19:"2018/05/CC_-044.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"CC_-044-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"CC_-044-277x300.jpg";s:5:"width";i:277;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"CC_-044-768x833.jpg";s:5:"width";i:768;s:6:"height";i:833;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"CC_-044-944x1024.jpg";s:5:"width";i:944;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(136, 52, '_thumbnail_id', '53'),
(137, 52, 'issue_subtitle', 'Universal, single-payer health care can be a reality in New York.'),
(138, 52, '_issue_subtitle', 'field_5b0492dc64d8c'),
(139, 54, 'issue_subtitle', 'Universal, single-payer health care can be a reality in New York.'),
(140, 54, '_issue_subtitle', 'field_5b0492dc64d8c'),
(141, 55, '_edit_last', '1'),
(142, 55, '_edit_lock', '1527163805:1'),
(145, 57, '_edit_last', '1'),
(146, 57, '_edit_lock', '1527186023:1'),
(151, 55, 'author', 'Alex Morris'),
(152, 55, '_author', 'field_5b068abd049f1'),
(153, 55, 'publisher', 'New York Magazine'),
(154, 55, '_publisher', 'field_5b068ad8049f2'),
(155, 55, 'publish_date', '20180319'),
(156, 55, '_publish_date', 'field_5b068ba2049f3'),
(157, 61, 'author', 'Alex Morris'),
(158, 61, '_author', 'field_5b068abd049f1'),
(159, 61, 'publisher', 'New York Magazine'),
(160, 61, '_publisher', 'field_5b068ad8049f2'),
(161, 61, 'publish_date', '20180319'),
(162, 61, '_publish_date', 'field_5b068ba2049f3'),
(165, 62, '_edit_last', '1'),
(166, 62, '_edit_lock', '1527159517:1'),
(167, 1, '_edit_last', '1'),
(170, 1, 'author', 'Test'),
(171, 1, '_author', 'field_5b068abd049f1'),
(172, 1, 'publisher', 'Test'),
(173, 1, '_publisher', 'field_5b068ad8049f2'),
(174, 1, 'publish_date', '20180503'),
(175, 1, '_publish_date', 'field_5b068ba2049f3'),
(176, 64, 'author', 'Test'),
(177, 64, '_author', 'field_5b068abd049f1'),
(178, 64, 'publisher', 'Test'),
(179, 64, '_publisher', 'field_5b068ad8049f2'),
(180, 64, 'publish_date', '20180503'),
(181, 64, '_publish_date', 'field_5b068ba2049f3'),
(182, 65, '_edit_last', '1'),
(183, 65, '_edit_lock', '1527163797:1'),
(186, 65, 'author', 'Test 2'),
(187, 65, '_author', 'field_5b068abd049f1'),
(188, 65, 'publisher', 'Test 2'),
(189, 65, '_publisher', 'field_5b068ad8049f2'),
(190, 65, 'publish_date', '20180524'),
(191, 65, '_publish_date', 'field_5b068ba2049f3'),
(192, 66, 'author', 'Test 2'),
(193, 66, '_author', 'field_5b068abd049f1'),
(194, 66, 'publisher', 'Test 2'),
(195, 66, '_publisher', 'field_5b068ad8049f2'),
(196, 66, 'publish_date', '20180524'),
(197, 66, '_publish_date', 'field_5b068ba2049f3'),
(198, 15, 'featured', 'a:3:{i:0;s:2:"55";i:1;s:2:"72";i:2;s:2:"65";}'),
(199, 15, '_featured', 'field_5b068e0f9c1ba'),
(200, 67, 'featured', '55'),
(201, 67, '_featured', 'field_5b068e0f9c1ba'),
(202, 68, 'featured', 'a:1:{i:0;s:2:"55";}'),
(203, 68, '_featured', 'field_5b068e0f9c1ba'),
(204, 69, 'featured', 'a:2:{i:0;s:2:"55";i:1;s:2:"65";}'),
(205, 69, '_featured', 'field_5b068e0f9c1ba'),
(206, 70, 'featured', 'a:2:{i:0;s:2:"65";i:1;s:2:"55";}'),
(207, 70, '_featured', 'field_5b068e0f9c1ba'),
(208, 71, 'featured', 'a:2:{i:0;s:2:"55";i:1;s:2:"65";}'),
(209, 71, '_featured', 'field_5b068e0f9c1ba'),
(210, 72, '_edit_last', '1'),
(211, 72, '_edit_lock', '1527163812:1'),
(214, 72, 'author', ''),
(215, 72, '_author', 'field_5b068abd049f1'),
(216, 72, 'publisher', ''),
(217, 72, '_publisher', 'field_5b068ad8049f2'),
(218, 72, 'publish_date', ''),
(219, 72, '_publish_date', 'field_5b068ba2049f3'),
(220, 74, 'author', ''),
(221, 74, '_author', 'field_5b068abd049f1'),
(222, 74, 'publisher', ''),
(223, 74, '_publisher', 'field_5b068ad8049f2'),
(224, 74, 'publish_date', ''),
(225, 74, '_publish_date', 'field_5b068ba2049f3'),
(228, 72, 'news_check', 'video'),
(229, 72, '_news_check', 'field_5b06a7e1cce6a'),
(230, 72, 'youtube_url', 'https://www.youtube.com/watch?v=Q3dSCcDu7hI'),
(231, 72, '_youtube_url', 'field_5b06a76d1b7ef'),
(232, 76, 'author', ''),
(233, 76, '_author', 'field_5b068abd049f1'),
(234, 76, 'publisher', ''),
(235, 76, '_publisher', 'field_5b068ad8049f2'),
(236, 76, 'publish_date', ''),
(237, 76, '_publish_date', 'field_5b068ba2049f3') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(238, 76, 'news_check', 'video'),
(239, 76, '_news_check', 'field_5b06a7e1cce6a'),
(240, 76, 'youtube_url', 'https://www.youtube.com/watch?v=Q3dSCcDu7hI'),
(241, 76, '_youtube_url', 'field_5b06a76d1b7ef'),
(244, 1, 'news_check', 'article'),
(245, 1, '_news_check', 'field_5b06a7e1cce6a'),
(246, 64, 'news_check', 'article'),
(247, 64, '_news_check', 'field_5b06a7e1cce6a'),
(250, 55, 'news_check', 'article'),
(251, 55, '_news_check', 'field_5b06a7e1cce6a'),
(252, 61, 'news_check', 'article'),
(253, 61, '_news_check', 'field_5b06a7e1cce6a'),
(256, 65, 'news_check', 'article'),
(257, 65, '_news_check', 'field_5b06a7e1cce6a'),
(258, 66, 'news_check', 'article'),
(259, 66, '_news_check', 'field_5b06a7e1cce6a'),
(264, 77, 'featured', 'a:3:{i:0;s:2:"55";i:1;s:2:"72";i:2;s:2:"65";}'),
(265, 77, '_featured', 'field_5b068e0f9c1ba'),
(266, 79, '_edit_last', '1'),
(267, 79, '_edit_lock', '1527188622:1'),
(268, 11, 'order', 'a:5:{i:0;s:2:"34";i:1;s:2:"43";i:2;s:2:"46";i:3;s:2:"52";i:4;s:2:"49";}'),
(269, 11, '_order', 'field_5b070c9dc1bdd'),
(270, 81, 'order', 'a:5:{i:0;s:2:"34";i:1;s:2:"43";i:2;s:2:"46";i:3;s:2:"52";i:4;s:2:"49";}'),
(271, 81, '_order', 'field_5b070c9dc1bdd'),
(281, 84, '_edit_last', '1'),
(282, 84, '_edit_lock', '1527197780:1'),
(283, 84, '_thumbnail_id', '42'),
(284, 84, 'issue_subtitle', 'Obvious test is obvious'),
(285, 84, '_issue_subtitle', 'field_5b0492dc64d8c'),
(286, 85, 'issue_subtitle', 'Obvious test is obvious'),
(287, 85, '_issue_subtitle', 'field_5b0492dc64d8c'),
(288, 86, 'issue_subtitle', 'Obvious test is obvious'),
(289, 86, '_issue_subtitle', 'field_5b0492dc64d8c'),
(290, 87, 'order', 'a:5:{i:0;s:2:"49";i:1;s:2:"34";i:2;s:2:"43";i:3;s:2:"46";i:4;s:2:"52";}'),
(291, 87, '_order', 'field_5b070c9dc1bdd'),
(292, 88, 'order', 'a:5:{i:0;s:2:"34";i:1;s:2:"43";i:2;s:2:"46";i:3;s:2:"52";i:4;s:2:"49";}'),
(293, 88, '_order', 'field_5b070c9dc1bdd') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-05-17 18:36:18', '2018-05-17 18:36:18', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-05-24 12:01:38', '2018-05-24 12:01:38', '', 0, 'http://catalina.test/?p=1', 0, 'post', '', 0),
(5, 1, '2018-05-17 20:26:59', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-05-17 20:26:59', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?post_type=issue&p=5', 0, 'issue', '', 0),
(6, 1, '2018-05-17 22:00:09', '2018-05-17 22:00:09', '{"blogname":{"value":"Catalina","type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:00:09"},"blogdescription":{"value":"","type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:00:09"}}', '', '', 'trash', 'closed', 'closed', '', '675e42b8-f357-43ab-b4b2-0e0ff82a9308', '', '', '2018-05-17 22:00:09', '2018-05-17 22:00:09', '', 0, 'http://catalina.test/?p=6', 0, 'customize_changeset', '', 0),
(7, 1, '2018-05-17 22:00:41', '2018-05-17 22:00:41', '{"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:00:41"},"page_on_front":{"value":"2","type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:00:41"}}', '', '', 'trash', 'closed', 'closed', '', 'f7ab6b2c-5fee-4db0-a09f-2e15a3890d6d', '', '', '2018-05-17 22:00:41', '2018-05-17 22:00:41', '', 0, 'http://catalina.test/?p=7', 0, 'customize_changeset', '', 0),
(8, 1, '2018-05-17 22:06:12', '2018-05-17 22:06:12', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2018-05-19 21:28:04', '2018-05-19 21:28:04', '', 0, 'http://catalina.test/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-05-17 22:06:12', '2018-05-17 22:06:12', '{"page_on_front":{"value":"8","type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:01:35"},"nav_menus_created_posts":{"value":[8],"type":"option","user_id":1,"date_modified_gmt":"2018-05-17 22:01:35"}}', '', '', 'trash', 'closed', 'closed', '', 'a4d99e2a-3b3f-4667-a321-af3cf72ce653', '', '', '2018-05-17 22:06:12', '2018-05-17 22:06:12', '', 0, 'http://catalina.test/?p=9', 0, 'customize_changeset', '', 0),
(10, 1, '2018-05-17 22:06:12', '2018-05-17 22:06:12', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-05-17 22:06:12', '2018-05-17 22:06:12', '', 8, 'http://catalina.test/?p=10', 0, 'revision', '', 0),
(11, 1, '2018-05-19 18:04:08', '2018-05-19 18:04:08', '', 'Issues', '', 'publish', 'closed', 'closed', '', 'issues', '', '', '2018-05-24 20:52:46', '2018-05-24 20:52:46', '', 0, 'http://catalina.test/?page_id=11', 0, 'page', '', 0),
(12, 1, '2018-05-19 18:04:08', '2018-05-19 18:04:08', '', 'Issues', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-05-19 18:04:08', '2018-05-19 18:04:08', '', 11, 'http://catalina.test/?p=12', 0, 'revision', '', 0),
(13, 1, '2018-05-19 20:40:32', '2018-05-19 20:40:32', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at the soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our community – to ensure our workers, neighbors, and families can not only survive, but thrive.\r\n\r\n&nbsp;\r\n\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\r\n\r\n&nbsp;\r\n\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'publish', 'closed', 'closed', '', 'meet-catalina', '', '', '2018-05-22 20:50:28', '2018-05-22 20:50:28', '', 0, 'http://catalina.test/?page_id=13', 0, 'page', '', 0),
(14, 1, '2018-05-19 20:40:32', '2018-05-19 20:40:32', '', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-19 20:40:32', '2018-05-19 20:40:32', '', 13, 'http://catalina.test/?p=14', 0, 'revision', '', 0),
(15, 1, '2018-05-19 20:41:33', '2018-05-19 20:41:33', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2018-05-24 12:28:28', '2018-05-24 12:28:28', '', 0, 'http://catalina.test/?page_id=15', 0, 'page', '', 0),
(16, 1, '2018-05-19 20:41:33', '2018-05-19 20:41:33', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-19 20:41:33', '2018-05-19 20:41:33', '', 15, 'http://catalina.test/?p=16', 0, 'revision', '', 0),
(18, 1, '2018-05-19 21:35:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-19 21:35:17', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?p=18', 1, 'nav_menu_item', '', 0),
(20, 1, '2018-05-19 21:36:27', '2018-05-19 21:36:27', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 0, 'http://catalina.test/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2018-05-19 21:36:27', '2018-05-19 21:36:27', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 0, 'http://catalina.test/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2018-05-19 21:36:27', '2018-05-19 21:36:27', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 0, 'http://catalina.test/?p=22', 3, 'nav_menu_item', '', 0),
(23, 1, '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 'Endorsements', '', 'publish', 'closed', 'closed', '', 'endorsements', '', '', '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 0, 'http://catalina.test/?p=23', 4, 'nav_menu_item', '', 0),
(24, 1, '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 'Events', '', 'publish', 'closed', 'closed', '', 'events', '', '', '2018-05-20 23:44:38', '2018-05-20 23:44:38', '', 0, 'http://catalina.test/?p=24', 5, 'nav_menu_item', '', 0),
(25, 1, '2018-05-21 09:34:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-21 09:34:01', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?post_type=acf-field-group&p=25', 0, 'acf-field-group', '', 0),
(26, 1, '2018-05-22 02:41:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-22 02:41:26', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?post_type=acf-field-group&p=26', 0, 'acf-field-group', '', 0),
(27, 1, '2018-05-22 02:41:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-22 02:41:29', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?post_type=acf-field-group&p=27', 0, 'acf-field-group', '', 0),
(28, 1, '2018-05-22 20:34:28', '2018-05-22 20:34:28', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of\r\nnine, and lived here for ten years without documentation. Although her mother had an\r\nadvanced degree in health care, she had to work menial jobs to make ends meet. As a\r\nsingle mother with four kids, she cleaned offices at night, sold tamales and empanadas at\r\nthe soccer fields on the weekend, and worked long hours as a nanny during the week.\r\nInspired by her mother’s perseverance, Catalina has committed her career to fight for our\r\ncommunity – to ensure our workers, neighbors, and families can not only survive, but\r\nthrive.\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers\r\nrights. She most recently served as the Chief of Staff for Council Member Julissa\r\nFerreras-Copeland, chair of the New York City Council Finance Committee. Catalina has\r\nworked to help pass key legislation protecting workers, women, and business owners. She\r\nhas previously served as the Director of Governor Andrew M. Cuomo\'s Exploited\r\nWorkers Task Force, helping New York become a national leader in the fight against\r\nworker exploitation. This first-of-its-kind task force conducted outreach and enforcement\r\nwithin key low wage industries statewide, including car washes, restaurants, and nail\r\nsalons, where workers are often victims of wage theft and subject to unsafe work\r\nconditions, but do not eat forward for fear of retaliation.\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens\r\nCounty. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish\r\nprogram which mentors students from St. John\'s and CUNY law schools and brings\r\n"Know Your Rights" presentations to underserved communities. Catalina holds BA from\r\nthe John Jay College of Criminal Justice and a JD from the City University of New York\r\nSchool of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the\r\nNew York City Police Department', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-22 20:34:28', '2018-05-22 20:34:28', '', 13, 'http://catalina.test/13-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2018-05-22 20:50:26', '2018-05-22 20:50:26', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at the soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our community – to ensure our workers, neighbors, and families can not only survive, but thrive.\n\n&nbsp;\n\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\n\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-autosave-v1', '', '', '2018-05-22 20:50:26', '2018-05-22 20:50:26', '', 13, 'http://catalina.test/13-autosave-v1/', 0, 'revision', '', 0),
(30, 1, '2018-05-22 20:44:42', '2018-05-22 20:44:42', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at\r\nthe soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our\r\ncommunity – to ensure our workers, neighbors, and families can not only survive, but thrive.\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-22 20:44:42', '2018-05-22 20:44:42', '', 13, 'http://catalina.test/13-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2018-05-22 20:46:38', '2018-05-22 20:46:38', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at\r\nthe soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our community – to ensure our workers, neighbors, and families can not only survive, but thrive.\r\n\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\r\n\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-22 20:46:38', '2018-05-22 20:46:38', '', 13, 'http://catalina.test/13-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2018-05-22 20:47:40', '2018-05-22 20:47:40', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at the soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our community – to ensure our workers, neighbors, and families can not only survive, but thrive.\r\n\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\r\n\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-22 20:47:40', '2018-05-22 20:47:40', '', 13, 'http://catalina.test/13-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2018-05-22 20:50:28', '2018-05-22 20:50:28', '<strong>Catalina Cruz is a DREAMer.</strong> She was born in Colombia, came to Queens at the age of nine, and lived here for ten years without documentation. Although her mother had an advanced degree in health care, she had to work menial jobs to make ends meet. As a single mother with four kids, she cleaned offices at night, sold tamales and empanadas at the soccer fields on the weekend, and worked long hours as a nanny during the week. Inspired by her mother’s perseverance, Catalina has committed her career to fight for our community – to ensure our workers, neighbors, and families can not only survive, but thrive.\r\n\r\n&nbsp;\r\n\r\nCatalina Cruz is an experienced attorney and a leader for immigration reform and workers rights. She most recently served as the Chief of Staff for Council Member Julissa Ferreras-Copeland, chair of the New York City Council Finance Committee. Catalina has worked to help pass key legislation protecting workers, women, and business owners. She has previously served as the Director of Governor Andrew M. Cuomo\'s Exploited Workers Task Force, helping New York become a national leader in the fight against worker exploitation. This first-of-its-kind task force conducted outreach and enforcement within key low wage industries statewide, including car washes, restaurants, and nail salons, where workers are often victims of wage theft and subject to unsafe work conditions, but do not eat forward for fear of retaliation.\r\n\r\n&nbsp;\r\n\r\nCatalina currently serves as the president of the Latino Lawyers Association of Queens County. For the past 5 years, she has coordinated the Association\'s Street Law in Spanish program which mentors students from St. John\'s and CUNY law schools and brings "Know Your Rights" presentations to underserved communities. Catalina holds BA from the John Jay College of Criminal Justice and a JD from the City University of New York School of Law. Catalina lives in Jackson Heights with her husband, a Sergeant with the New York City Police Department.', 'Meet Catalina', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-22 20:50:28', '2018-05-22 20:50:28', '', 13, 'http://catalina.test/13-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2018-05-22 21:59:49', '2018-05-22 21:59:49', '<strong>The decline of the MTA did not happen overnight.</strong> For more than 30 years, funding for the system (including funding for capital projects) has been cut at the state and city level. Ridership has increased, while maintenance spending has declined, directly impacting the MTA’s on-time performance and creating a legacy of lateness. The Authority is now almost completely reliant on fares, tolls, and revenue from taxes and fees earmarked for transit- while existing debt obligations balloon.\r\n\r\n&nbsp;\r\n\r\nWorking families in our community rely on public transportation to get to work, to get to school, to get around our city. The never-ending delays on trains and buses are costing us our livelihood. Short and long term solutions are needed in order to provide New Yorkers with the quality of service they deserve and have paid for over the decades:\r\n\r\n&nbsp;\r\n\r\n• The MTA must work to immediately decrease the existing times allotted for repairs to be made, and concentrate on repairs that affect on time ridership, rather than cosmetic upgrades.\r\n\r\n&nbsp;\r\n\r\n• The MTA, as it exists must be broken up into several agencies capable of managing smaller systems. Control over the City’s transit system (train and buses) must be handed over to New York City.\r\n\r\n&nbsp;\r\n\r\n• The existing debt must be restructured to facilitate free cash flow and allow for spending on repairs.', 'Fix The MTA', '', 'publish', 'open', 'closed', '', 'fix-the-mta', '', '', '2018-05-23 01:30:11', '2018-05-23 01:30:11', '', 0, 'http://catalina.test/?post_type=issue&#038;p=34', 0, 'issue', '', 0),
(35, 1, '2018-05-22 22:01:24', '2018-05-22 22:01:24', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"issue";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Issue', 'issue', 'publish', 'closed', 'closed', '', 'group_5b049184e7130', '', '', '2018-05-22 22:05:11', '2018-05-22 22:05:11', '', 0, 'http://catalina.test/?post_type=acf-field-group&#038;p=35', 0, 'acf-field-group', '', 0),
(37, 1, '2018-05-22 21:59:49', '2018-05-22 21:59:49', '', 'Fix The MTA', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-05-22 21:59:49', '2018-05-22 21:59:49', '', 34, 'http://catalina.test/34-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2018-05-22 22:01:24', '2018-05-22 22:01:24', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Issue Subtitle', 'issue_subtitle', 'publish', 'closed', 'closed', '', 'field_5b0492dc64d8c', '', '', '2018-05-22 22:05:11', '2018-05-22 22:05:11', '', 35, 'http://catalina.test/?post_type=acf-field&#038;p=38', 0, 'acf-field', '', 0),
(39, 1, '2018-05-22 22:04:25', '2018-05-22 22:04:25', '<strong>The decline of the MTA did not happen overnight.</strong> For more than 30 years, funding for the system (including funding for capital projects) has been cut at the state and city level. Ridership has increased, while maintenance spending has declined, directly impacting the MTA’s on-time performance and creating a legacy of lateness. The Authority is now almost completely reliant on fares, tolls, and revenue from taxes and fees earmarked for transit- while existing debt obligations balloon.\n\n&nbsp;\n\nWorking families in our community rely on public transportation to get to work, to get to school, to get around our city. The never-ending delays on trains and buses are costing us our livelihood. Short and long term solutions are needed in order to provide New Yorkers with the quality of service they deserve and have paid for over the decades:\n• The MTA must work to immediately decrease the existing times allotted for repairs to be made, and concentrate on repairs that affect on time ridership, rather than cosmetic upgrades.\n• The MTA, as it exists must be broken up into several agencies capable of managing smaller systems. Control over the City’s transit system (train and buses) must be handed over to New York City.\n• The existing debt must be restructured to facilitate free cash flow and allow for spending on repairs.', 'Fix The MTA', '', 'inherit', 'closed', 'closed', '', '34-autosave-v1', '', '', '2018-05-22 22:04:25', '2018-05-22 22:04:25', '', 34, 'http://catalina.test/34-autosave-v1/', 0, 'revision', '', 0),
(40, 1, '2018-05-22 22:04:40', '2018-05-22 22:04:40', '<strong>The decline of the MTA did not happen overnight.</strong> For more than 30 years, funding for the system (including funding for capital projects) has been cut at the state and city level. Ridership has increased, while maintenance spending has declined, directly impacting the MTA’s on-time performance and creating a legacy of lateness. The Authority is now almost completely reliant on fares, tolls, and revenue from taxes and fees earmarked for transit- while existing debt obligations balloon.\r\n\r\n&nbsp;\r\n\r\nWorking families in our community rely on public transportation to get to work, to get to school, to get around our city. The never-ending delays on trains and buses are costing us our livelihood. Short and long term solutions are needed in order to provide New Yorkers with the quality of service they deserve and have paid for over the decades:\r\n\r\n&nbsp;\r\n\r\n• The MTA must work to immediately decrease the existing times allotted for repairs to be made, and concentrate on repairs that affect on time ridership, rather than cosmetic upgrades.\r\n\r\n&nbsp;\r\n\r\n• The MTA, as it exists must be broken up into several agencies capable of managing smaller systems. Control over the City’s transit system (train and buses) must be handed over to New York City.\r\n\r\n&nbsp;\r\n\r\n• The existing debt must be restructured to facilitate free cash flow and allow for spending on repairs.', 'Fix The MTA', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-05-22 22:04:40', '2018-05-22 22:04:40', '', 34, 'http://catalina.test/34-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-05-22 22:05:25', '2018-05-22 22:05:25', '<strong>The decline of the MTA did not happen overnight.</strong> For more than 30 years, funding for the system (including funding for capital projects) has been cut at the state and city level. Ridership has increased, while maintenance spending has declined, directly impacting the MTA’s on-time performance and creating a legacy of lateness. The Authority is now almost completely reliant on fares, tolls, and revenue from taxes and fees earmarked for transit- while existing debt obligations balloon.\r\n\r\n&nbsp;\r\n\r\nWorking families in our community rely on public transportation to get to work, to get to school, to get around our city. The never-ending delays on trains and buses are costing us our livelihood. Short and long term solutions are needed in order to provide New Yorkers with the quality of service they deserve and have paid for over the decades:\r\n\r\n&nbsp;\r\n\r\n• The MTA must work to immediately decrease the existing times allotted for repairs to be made, and concentrate on repairs that affect on time ridership, rather than cosmetic upgrades.\r\n\r\n&nbsp;\r\n\r\n• The MTA, as it exists must be broken up into several agencies capable of managing smaller systems. Control over the City’s transit system (train and buses) must be handed over to New York City.\r\n\r\n&nbsp;\r\n\r\n• The existing debt must be restructured to facilitate free cash flow and allow for spending on repairs.', 'Fix The MTA', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-05-22 22:05:25', '2018-05-22 22:05:25', '', 34, 'http://catalina.test/34-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2018-05-23 01:30:05', '2018-05-23 01:30:05', '', 'CC_-027-0', '', 'inherit', 'open', 'closed', '', 'cc_-027-0', '', '', '2018-05-23 01:30:05', '2018-05-23 01:30:05', '', 34, 'http://catalina.test/wp-content/uploads/2018/05/CC_-027-0.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2018-05-23 02:16:07', '2018-05-23 02:16:07', '', 'Invest in Public Education', '', 'publish', 'open', 'closed', '', 'invest-in-public-education', '', '', '2018-05-23 02:16:07', '2018-05-23 02:16:07', '', 0, 'http://catalina.test/?post_type=issue&#038;p=43', 0, 'issue', '', 0),
(44, 1, '2018-05-23 02:15:00', '2018-05-23 02:15:00', '', 'CC_-060', '', 'inherit', 'open', 'closed', '', 'cc_-060', '', '', '2018-05-23 02:15:00', '2018-05-23 02:15:00', '', 43, 'http://catalina.test/wp-content/uploads/2018/05/CC_-060.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2018-05-23 02:16:07', '2018-05-23 02:16:07', '', 'Invest in Public Education', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-05-23 02:16:07', '2018-05-23 02:16:07', '', 43, 'http://catalina.test/43-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2018-05-23 02:50:54', '2018-05-23 02:50:54', '', 'Keep Housing Affordable', '', 'publish', 'open', 'closed', '', 'keep-housing-affordable', '', '', '2018-05-23 02:50:54', '2018-05-23 02:50:54', '', 0, 'http://catalina.test/?post_type=issue&#038;p=46', 0, 'issue', '', 0),
(47, 1, '2018-05-23 02:50:44', '2018-05-23 02:50:44', '', 'CC_-072', '', 'inherit', 'open', 'closed', '', 'cc_-072', '', '', '2018-05-23 02:50:44', '2018-05-23 02:50:44', '', 46, 'http://catalina.test/wp-content/uploads/2018/05/CC_-072.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2018-05-23 02:50:54', '2018-05-23 02:50:54', '', 'Keep Housing Affordable', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-05-23 02:50:54', '2018-05-23 02:50:54', '', 46, 'http://catalina.test/46-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2018-05-23 03:24:23', '2018-05-23 03:24:23', '', 'Support Immigrants', '', 'publish', 'open', 'closed', '', 'support-immigrants', '', '', '2018-05-23 03:24:23', '2018-05-23 03:24:23', '', 0, 'http://catalina.test/?post_type=issue&#038;p=49', 0, 'issue', '', 0),
(50, 1, '2018-05-23 03:23:51', '2018-05-23 03:23:51', '', 'CC_-026-0', '', 'inherit', 'open', 'closed', '', 'cc_-026-0', '', '', '2018-05-23 03:23:51', '2018-05-23 03:23:51', '', 49, 'http://catalina.test/wp-content/uploads/2018/05/CC_-026-0.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2018-05-23 03:24:23', '2018-05-23 03:24:23', '', 'Support Immigrants', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2018-05-23 03:24:23', '2018-05-23 03:24:23', '', 49, 'http://catalina.test/49-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-05-23 03:52:14', '2018-05-23 03:52:14', '', 'Medicare For All', '', 'publish', 'open', 'closed', '', 'medicare-for-all', '', '', '2018-05-23 03:52:14', '2018-05-23 03:52:14', '', 0, 'http://catalina.test/?post_type=issue&#038;p=52', 0, 'issue', '', 0),
(53, 1, '2018-05-23 03:51:55', '2018-05-23 03:51:55', '', 'CC_-044', '', 'inherit', 'open', 'closed', '', 'cc_-044', '', '', '2018-05-23 03:51:55', '2018-05-23 03:51:55', '', 52, 'http://catalina.test/wp-content/uploads/2018/05/CC_-044.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2018-05-23 03:52:14', '2018-05-23 03:52:14', '', 'Medicare For All', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-05-23 03:52:14', '2018-05-23 03:52:14', '', 52, 'http://catalina.test/52-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2018-05-24 09:48:55', '2018-05-24 09:48:55', '"I’m a punk when it comes to pain,” admits Catalina Cruz. “I’ll cry from a paper cut.” These are not sentiments one would expect from someone entering the pummeling world of American politics, but Cruz is currently standing in front of the Queens establishment where she got her ears pierced 24 years ago. She peers through the window at the baubles on display before continuing on, her rain boots making a muffled clomp on the sidewalks of Jackson Heights — one of several neighborhoods that comprise District 39, the vacant Assembly seat of which Cruz hopes to fill after the primary election this September.\r\n\r\n&nbsp;\r\n\r\nCruz, who became a U.S. citizen in 2009, is currently the first Dreamer to run for office in New York state; if she wins, she will be the third Dreamer to ever take office in this country (after Wendy Carrillo of California and Ruben Kihuen of Nevada). In 1992, at the age of 9, she boarded a plane in Medellin, where she could see Pablo Escobar’s jail from the sidewalk of her childhood home. She arrived at JFK accompanied by her single mother, wearing her favorite outfit — a “pant situation with a shirt that had too many ruffles; it was not cute” — and carrying a tourist visa set to expire in six months. Growing up, this stretch of 82nd Street is where she came to tap into the Colombian community vibe. First stop: Las Americas Bakery, established in 1976 but since closed, never again to grace the world with their buñuelos. Then there’s the butcher across the street that currently sells not meat but empanadas. And, just up the block, the construction site where a teenage Cruz saw Blade and Charlie’s Angels in the movie theater that used to be there. It’s now slated to be a Target. “I think it does something to the soul of the district,” Cruz says. “You’re not going to get empanadas at Target.”\r\n\r\n&nbsp;\r\n\r\nOur ultimate destination is the corner of 82nd and Roosevelt Avenue under the elevated 7 train where, during her first few years in New York, Cruz’s mother handed out restaurant fliers for around $40 a day. Just last week, Cruz saw a woman on that very corner doing that very thing, and she couldn’t help but stop and talk to her. “She told me she’s Ecuadorian. She told me she does this Monday through Friday, 9 to 5, and they pay her $13 an hour, which is above minimum wage.” Cruz raises an eyebrow. “She’s doing this for an immigration attorney, so you would hope they’re going to pay her at least minimum wage, but she still can’t make ends meet.” The woman’s name was Rosa, which also happens to be Cruz’s mother’s name.', 'Meet Catalina Cruz, the Queens Dreamer Running for Office', '', 'publish', 'open', 'open', '', 'meet-catalina-cruz-the-queens-dreamer-running-for-office', '', '', '2018-05-24 12:12:26', '2018-05-24 12:12:26', '', 0, 'http://catalina.test/?p=55', 0, 'post', '', 0),
(56, 1, '2018-05-24 09:48:55', '2018-05-24 09:48:55', '"I’m a punk when it comes to pain,” admits Catalina Cruz. “I’ll cry from a paper cut.” These are not sentiments one would expect from someone entering the pummeling world of American politics, but Cruz is currently standing in front of the Queens establishment where she got her ears pierced 24 years ago. She peers through the window at the baubles on display before continuing on, her rain boots making a muffled clomp on the sidewalks of Jackson Heights — one of several neighborhoods that comprise District 39, the vacant Assembly seat of which Cruz hopes to fill after the primary election this September.\r\n\r\n&nbsp;\r\n\r\nCruz, who became a U.S. citizen in 2009, is currently the first Dreamer to run for office in New York state; if she wins, she will be the third Dreamer to ever take office in this country (after Wendy Carrillo of California and Ruben Kihuen of Nevada). In 1992, at the age of 9, she boarded a plane in Medellin, where she could see Pablo Escobar’s jail from the sidewalk of her childhood home. She arrived at JFK accompanied by her single mother, wearing her favorite outfit — a “pant situation with a shirt that had too many ruffles; it was not cute” — and carrying a tourist visa set to expire in six months. Growing up, this stretch of 82nd Street is where she came to tap into the Colombian community vibe. First stop: Las Americas Bakery, established in 1976 but since closed, never again to grace the world with their buñuelos. Then there’s the butcher across the street that currently sells not meat but empanadas. And, just up the block, the construction site where a teenage Cruz saw Blade and Charlie’s Angels in the movie theater that used to be there. It’s now slated to be a Target. “I think it does something to the soul of the district,” Cruz says. “You’re not going to get empanadas at Target.”\r\n\r\n&nbsp;\r\n\r\nOur ultimate destination is the corner of 82nd and Roosevelt Avenue under the elevated 7 train where, during her first few years in New York, Cruz’s mother handed out restaurant fliers for around $40 a day. Just last week, Cruz saw a woman on that very corner doing that very thing, and she couldn’t help but stop and talk to her. “She told me she’s Ecuadorian. She told me she does this Monday through Friday, 9 to 5, and they pay her $13 an hour, which is above minimum wage.” Cruz raises an eyebrow. “She’s doing this for an immigration attorney, so you would hope they’re going to pay her at least minimum wage, but she still can’t make ends meet.” The woman’s name was Rosa, which also happens to be Cruz’s mother’s name.', 'Meet Catalina Cruz, the Queens Dreamer Running for Office', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2018-05-24 09:48:55', '2018-05-24 09:48:55', '', 55, 'http://catalina.test/55-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2018-05-24 09:56:34', '2018-05-24 09:56:34', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'News', 'news', 'publish', 'closed', 'closed', '', 'group_5b068ab5e557d', '', '', '2018-05-24 12:09:24', '2018-05-24 12:09:24', '', 0, 'http://catalina.test/?post_type=acf-field-group&#038;p=57', 0, 'acf-field-group', '', 0),
(58, 1, '2018-05-24 09:56:34', '2018-05-24 09:56:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5b06a7e1cce6a";s:8:"operator";s:2:"==";s:5:"value";s:7:"article";}}}}', 'Author', 'author', 'publish', 'closed', 'closed', '', 'field_5b068abd049f1', '', '', '2018-05-24 11:56:50', '2018-05-24 11:56:50', '', 57, 'http://catalina.test/?post_type=acf-field&#038;p=58', 1, 'acf-field', '', 0),
(59, 1, '2018-05-24 09:56:34', '2018-05-24 09:56:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5b06a7e1cce6a";s:8:"operator";s:2:"==";s:5:"value";s:7:"article";}}}}', 'Publisher', 'publisher', 'publish', 'closed', 'closed', '', 'field_5b068ad8049f2', '', '', '2018-05-24 11:56:50', '2018-05-24 11:56:50', '', 57, 'http://catalina.test/?post_type=acf-field&#038;p=59', 2, 'acf-field', '', 0),
(60, 1, '2018-05-24 09:56:34', '2018-05-24 09:56:34', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:6:"F j, Y";s:9:"first_day";i:1;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5b06a7e1cce6a";s:8:"operator";s:2:"==";s:5:"value";s:7:"article";}}}}', 'Publish date', 'publish_date', 'publish', 'closed', 'closed', '', 'field_5b068ba2049f3', '', '', '2018-05-24 11:56:50', '2018-05-24 11:56:50', '', 57, 'http://catalina.test/?post_type=acf-field&#038;p=60', 3, 'acf-field', '', 0),
(61, 1, '2018-05-24 09:57:32', '2018-05-24 09:57:32', '"I’m a punk when it comes to pain,” admits Catalina Cruz. “I’ll cry from a paper cut.” These are not sentiments one would expect from someone entering the pummeling world of American politics, but Cruz is currently standing in front of the Queens establishment where she got her ears pierced 24 years ago. She peers through the window at the baubles on display before continuing on, her rain boots making a muffled clomp on the sidewalks of Jackson Heights — one of several neighborhoods that comprise District 39, the vacant Assembly seat of which Cruz hopes to fill after the primary election this September.\r\n\r\n&nbsp;\r\n\r\nCruz, who became a U.S. citizen in 2009, is currently the first Dreamer to run for office in New York state; if she wins, she will be the third Dreamer to ever take office in this country (after Wendy Carrillo of California and Ruben Kihuen of Nevada). In 1992, at the age of 9, she boarded a plane in Medellin, where she could see Pablo Escobar’s jail from the sidewalk of her childhood home. She arrived at JFK accompanied by her single mother, wearing her favorite outfit — a “pant situation with a shirt that had too many ruffles; it was not cute” — and carrying a tourist visa set to expire in six months. Growing up, this stretch of 82nd Street is where she came to tap into the Colombian community vibe. First stop: Las Americas Bakery, established in 1976 but since closed, never again to grace the world with their buñuelos. Then there’s the butcher across the street that currently sells not meat but empanadas. And, just up the block, the construction site where a teenage Cruz saw Blade and Charlie’s Angels in the movie theater that used to be there. It’s now slated to be a Target. “I think it does something to the soul of the district,” Cruz says. “You’re not going to get empanadas at Target.”\r\n\r\n&nbsp;\r\n\r\nOur ultimate destination is the corner of 82nd and Roosevelt Avenue under the elevated 7 train where, during her first few years in New York, Cruz’s mother handed out restaurant fliers for around $40 a day. Just last week, Cruz saw a woman on that very corner doing that very thing, and she couldn’t help but stop and talk to her. “She told me she’s Ecuadorian. She told me she does this Monday through Friday, 9 to 5, and they pay her $13 an hour, which is above minimum wage.” Cruz raises an eyebrow. “She’s doing this for an immigration attorney, so you would hope they’re going to pay her at least minimum wage, but she still can’t make ends meet.” The woman’s name was Rosa, which also happens to be Cruz’s mother’s name.', 'Meet Catalina Cruz, the Queens Dreamer Running for Office', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2018-05-24 09:57:32', '2018-05-24 09:57:32', '', 55, 'http://catalina.test/55-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-05-24 10:06:32', '2018-05-24 10:06:32', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"15";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Featured News', 'featured-news', 'publish', 'closed', 'closed', '', 'group_5b068e052fee0', '', '', '2018-05-24 10:26:32', '2018-05-24 10:26:32', '', 0, 'http://catalina.test/?post_type=acf-field-group&#038;p=62', 0, 'acf-field-group', '', 0),
(63, 1, '2018-05-24 10:06:32', '2018-05-24 10:06:32', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"post";}s:8:"taxonomy";a:0:{}s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:2:"id";}', 'Featured', 'featured', 'publish', 'closed', 'closed', '', 'field_5b068e0f9c1ba', '', '', '2018-05-24 10:26:32', '2018-05-24 10:26:32', '', 62, 'http://catalina.test/?post_type=acf-field&#038;p=63', 0, 'acf-field', '', 0),
(64, 1, '2018-05-24 10:07:29', '2018-05-24 10:07:29', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-05-24 10:07:29', '2018-05-24 10:07:29', '', 1, 'http://catalina.test/1-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2018-05-24 10:09:04', '2018-05-24 10:09:04', 'I’m a punk when it comes to pain,” admits Catalina Cruz. “I’ll cry from a paper cut.”\r\nThese are not sentiments one would expect from someone entering the pummeling world\r\nof American politics, but Cruz is currently standing in front of the Queens establishment\r\nwhere she got her ears pierced 24 years ago. She peers through the win', 'Test 2', '', 'publish', 'open', 'open', '', 'test-2', '', '', '2018-05-24 12:12:19', '2018-05-24 12:12:19', '', 0, 'http://catalina.test/?p=65', 0, 'post', '', 0),
(66, 1, '2018-05-24 10:09:04', '2018-05-24 10:09:04', 'I’m a punk when it comes to pain,” admits Catalina Cruz. “I’ll cry from a paper cut.”\r\nThese are not sentiments one would expect from someone entering the pummeling world\r\nof American politics, but Cruz is currently standing in front of the Queens establishment\r\nwhere she got her ears pierced 24 years ago. She peers through the win', 'Test 2', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2018-05-24 10:09:04', '2018-05-24 10:09:04', '', 65, 'http://catalina.test/65-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2018-05-24 10:09:44', '2018-05-24 10:09:44', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 10:09:44', '2018-05-24 10:09:44', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-05-24 10:11:12', '2018-05-24 10:11:12', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 10:11:12', '2018-05-24 10:11:12', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2018-05-24 10:29:45', '2018-05-24 10:29:45', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 10:29:45', '2018-05-24 10:29:45', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-05-24 10:30:07', '2018-05-24 10:30:07', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 10:30:07', '2018-05-24 10:30:07', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2018-05-24 10:30:31', '2018-05-24 10:30:31', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 10:30:31', '2018-05-24 10:30:31', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2018-05-24 11:53:48', '2018-05-24 11:53:48', '', 'MLK Vigil', '', 'publish', 'open', 'open', '', 'mlk-vigil', '', '', '2018-05-24 12:12:33', '2018-05-24 12:12:33', '', 0, 'http://catalina.test/?p=72', 0, 'post', '', 0),
(73, 1, '2018-05-24 11:53:40', '2018-05-24 11:53:40', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_5b06a7e1cce6a";s:8:"operator";s:2:"==";s:5:"value";s:5:"video";}}}}', 'Youtube Url', 'youtube_url', 'publish', 'closed', 'closed', '', 'field_5b06a76d1b7ef', '', '', '2018-05-24 11:56:50', '2018-05-24 11:56:50', '', 57, 'http://catalina.test/?post_type=acf-field&#038;p=73', 4, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(74, 1, '2018-05-24 11:53:48', '2018-05-24 11:53:48', '', 'MLK Vigil', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2018-05-24 11:53:48', '2018-05-24 11:53:48', '', 72, 'http://catalina.test/72-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2018-05-24 11:55:51', '2018-05-24 11:55:51', 'a:12:{s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:7:"article";s:7:"Article";s:5:"video";s:5:"Video";}s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:17:"save_other_choice";i:0;s:13:"default_value";s:0:"";s:6:"layout";s:10:"horizontal";s:13:"return_format";s:5:"array";}', 'Article or Video', 'news_check', 'publish', 'closed', 'closed', '', 'field_5b06a7e1cce6a', '', '', '2018-05-24 12:09:24', '2018-05-24 12:09:24', '', 57, 'http://catalina.test/?post_type=acf-field&#038;p=75', 0, 'acf-field', '', 0),
(76, 1, '2018-05-24 11:58:24', '2018-05-24 11:58:24', '', 'MLK Vigil', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2018-05-24 11:58:24', '2018-05-24 11:58:24', '', 72, 'http://catalina.test/72-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2018-05-24 12:28:28', '2018-05-24 12:28:28', '', 'News', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 12:28:28', '2018-05-24 12:28:28', '', 15, 'http://catalina.test/15-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2018-05-24 18:22:47', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-24 18:22:47', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?post_type=acf-field-group&p=78', 0, 'acf-field-group', '', 0),
(79, 1, '2018-05-24 19:05:50', '2018-05-24 19:05:50', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"11";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Issues Order', 'issues-order', 'publish', 'closed', 'closed', '', 'group_5b070c95cab08', '', '', '2018-05-24 19:06:03', '2018-05-24 19:06:03', '', 0, 'http://catalina.test/?post_type=acf-field-group&#038;p=79', 0, 'acf-field-group', '', 0),
(80, 1, '2018-05-24 19:05:50', '2018-05-24 19:05:50', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:65:"Arrange Issues In Order of Desired Page Display. (Topmost is 1st)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:5:"issue";}s:8:"taxonomy";a:0:{}s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:2:"id";}', 'Order', 'order', 'publish', 'closed', 'closed', '', 'field_5b070c9dc1bdd', '', '', '2018-05-24 19:05:50', '2018-05-24 19:05:50', '', 79, 'http://catalina.test/?post_type=acf-field&p=80', 0, 'acf-field', '', 0),
(81, 1, '2018-05-24 19:06:32', '2018-05-24 19:06:32', '', 'Issues', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-05-24 19:06:32', '2018-05-24 19:06:32', '', 11, 'http://catalina.test/11-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2018-05-24 20:48:39', '2018-05-24 20:48:39', 'ewfewfew', 'Test 9', '', 'publish', 'open', 'closed', '', 'test-9', '', '', '2018-05-24 20:50:52', '2018-05-24 20:50:52', '', 0, 'http://catalina.test/?post_type=issue&#038;p=84', 0, 'issue', '', 0),
(85, 1, '2018-05-24 20:48:39', '2018-05-24 20:48:39', '', 'Test 9', '', 'inherit', 'closed', 'closed', '', '84-revision-v1', '', '', '2018-05-24 20:48:39', '2018-05-24 20:48:39', '', 84, 'http://catalina.test/84-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2018-05-24 20:50:52', '2018-05-24 20:50:52', 'ewfewfew', 'Test 9', '', 'inherit', 'closed', 'closed', '', '84-revision-v1', '', '', '2018-05-24 20:50:52', '2018-05-24 20:50:52', '', 84, 'http://catalina.test/84-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2018-05-24 20:52:30', '2018-05-24 20:52:30', '', 'Issues', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-05-24 20:52:30', '2018-05-24 20:52:30', '', 11, 'http://catalina.test/11-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2018-05-24 20:52:46', '2018-05-24 20:52:46', '', 'Issues', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-05-24 20:52:46', '2018-05-24 20:52:46', '', 11, 'http://catalina.test/11-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2018-05-24 21:14:45', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-05-24 21:14:45', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?p=89', 0, 'post', '', 0),
(90, 1, '2018-05-24 21:18:35', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-05-24 21:18:35', '0000-00-00 00:00:00', '', 0, 'http://catalina.test/?p=90', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(55, 1, 0),
(65, 1, 0),
(72, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'nav_menu', '', 0, 5) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Home', 'home', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"49e242b470a22b4b2d944af81638f54bee923fe93d5cff1ea8e54e7e19d7dad1";a:4:{s:10:"expiration";i:1527791837;s:2:"ip";s:12:"192.168.50.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36";s:5:"login";i:1526582237;}s:64:"c1942d0b58ffeaff80a0cb9497cc07960aa0bc9b62ba814529c78e69b070499e";a:4:{s:10:"expiration";i:1527794878;s:2:"ip";s:12:"192.168.50.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36";s:5:"login";i:1526585278;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '89'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:12:"192.168.50.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:19:"add-post-type-issue";i:1;s:12:"add-post_tag";i:2;s:8:"add-type";}'),
(21, 1, 'wp_user-settings', 'mfold=o&editor=tinymce&libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1527026385') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BhUZ/xUjjJdkPRorCT2G3Ntzrqvz1d1', 'admin', 'admin@local.test', '', '2018-05-17 18:36:18', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

